<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class aboutus extends Model
{
    protected $fillable=['aboutus_in_english','aboutus_in_arabic'];
}
