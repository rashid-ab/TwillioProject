<?php

namespace App\Http\Controllers;

use App\User;
use App\Service;
use App\c;
use Illuminate\Http\Request;
use File;
use Storage;
use Auth;
use Mail;
use App\Category;
use App\Product;
use App\Setting;
use App\Order;
use App\Orderdetail;
use App\Web_common;
use App\Address;
use Carbon\Carbon;
use GuzzleHttp\Client;
// use App\Order;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
public function zip(Request $request){
    return 'asd';
    }
     public function zip_index(){
    return view('zip');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $user_array=array();
     
     $email=User::where('email',$request->email)->first();
    if(!is_null($email)){
        return response()->json(['status'=>"400",
       'description'=> "error",
       'message'=>"Duplication Email",'data'=>'']);
    }
   if($request->appartment==0){
    $appartment=0;
    $vila=$request->vila;
   }
   if($request->vila==0){
    $vila=0;
    $appartment=$request->appartment;
   }

// $list_no_rooms=serialize($request->no_rooms);
if($request->hasfile('avatar')){
    $file=$request->file('avatar');
    $file_name=time().'.'.$file->getClientOriginalName();
    $destinationPaths1 = app()->basePath('public/avatar');
    $file->move( $destinationPaths1,$file_name);


        $user=User::create([
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'avatar'=>url('/').'/public/avatar/'.$file_name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'phone_number'=>$request->phone_number,
            'device_token'=>$request->device_token,
            'delete_status'=>1,
            'status'=>1,
            'roles'=>'user',
        ]);
        $address=Address::create([
            'user_id'=>$user->id,
            'region'=>$request->region,
            'appartment'=>$appartment,
            'address'=>$request->address,
            'city'=>$request->city,
            'vila'=>$vila,
            'building_no'=>$request->building_no,
            'flat_no'=>$request->flat_no,
            'house_no'=>$request->house_no,
            
        ]);

        $user_array=array(
            'first_name'=>$user->first_name,
            'last_name'=>$user->last_name,
            'avatar'=>$user->avatar,
            'email'=>$user->email,
            'phone_number'=>$user->phone_number,
            'device_token'=>$user->device_token,
            'email_verified_at'=>$user->email_verified_at,
            'social_token'=>$user->social_token,
            'app_token'=>$user->app_token,
            'social_name'=>$user->social_name,
            'roles'=>$user->roles,
            'region'=>$address->region,
            'appartment'=>$address->appartment,
            'city'=>$address->city,
            'vila'=>$address->vila,
            'building_no'=>$address->building_no,
            'flat_no'=>$address->flat_no,
            'house_no'=>$address->house_no,
            'delete_status'=>$user->delete_status,
            'status'=>$user->status,     
     );
        $user_detail=User::where('id',$user->id)->first();
        return response()->json(['status'=>"200",
       'description'=> "signup",
       'message'=>"success",'data'=>$user_array]);
}
else{


     $user=User::create([
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'avatar'=>'',
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'phone_number'=>$request->phone_number,
            'device_token'=>$request->device_token,
            'delete_status'=>1,
            'status'=>1,
            'roles'=>'user',
        ]);
     $address=Address::create([
            'user_id'=>$user->id,
            'region'=>$request->region,
            'appartment'=>$appartment,
            'city'=>$request->city,
            'vila'=>$vila,
            'building_no'=>$request->building_no,
            'flat_no'=>$request->flat_no,
            'house_no'=>$request->house_no,
            
        ]);
     $user_array=array(
            'first_name'=>$user->first_name,
            'last_name'=>$user->last_name,
            'avatar'=>$user->avatar,
            'email'=>$user->email,
            'phone_number'=>$user->phone_number,
            'device_token'=>$user->device_token,
            'email_verified_at'=>$user->email_verified_at,
            'social_token'=>$user->social_token,
            'app_token'=>$user->app_token,
            'social_name'=>$user->social_name,
            'roles'=>$user->roles,
            'region'=>$address->region,
            'appartment'=>$address->appartment,
            'city'=>$address->city,
            'vila'=>$address->vila,
            'building_no'=>$address->building_no,
            'flat_no'=>$address->flat_no,
            'house_no'=>$address->house_no,
            'delete_status'=>$user->delete_status,
            'status'=>$user->status,
     );
    $user_detail=User::where('id',$user->id)->first();
        return response()->json(['status'=>"200",
       'description'=> "signup",
       'message'=>"success",'data'=>$user_array]);
}
}

    public function login(Request $request){
        $check=1;
        $login=auth::attempt(array('email' => $request->email, 'password' => $request->password ,'status' => $check ,'delete_status' => $check));
        if($login==false){
        $fail=DB::table('users')->where('email',$request->email)->first();
        if(!is_null($fail)){
        if($fail->status==0 || $fail->delete_status==0){
                return response()->json(['status'=>"401",
                'description'=> "error",
                'message'=>"Your account is blocked. Please contact with admin",'data'=>'N/A']);
        }
        }
        else{
        return response()->json(['status'=>"400",
       'description'=> "error",
       'message'=>"no user exist",'data'=>'N/A']);
            }
        return response()->json(['status'=>"400",
       'description'=> "error",
       'message'=>"no user exist",'data'=>'N/A']);
        }
        if($login==true){
            $token = openssl_random_pseudo_bytes(16);
                $token = bin2hex($token);
            User::where('email',$request->email)->update([
               'app_token'=>$token,
                'device_token'=>$request->device_token,
                ]);
            $em_user=User::where('email',$request->email)->first();
        return response()->json(['status'=>"200",
       'description'=> "signin",
       'message'=>"success",'data'=>$em_user]);
        }

    }

    public function logout(Request $request){
        $user=User::where('id',$request->user_id)->update([
            'app_token'=>'0',
            // 'device_token'=>'0'
            ]);
        return response()->json(['status'=>"200",
       'description'=> "logout",
       'message'=>"success",'data'=>'']);
    }
    public function forgetpassword(Request $request){
        $email=$request->email;
        $user=User::where('email',$email)->first();
        if(!is_null($user)){
        $hashed_random_password = str_random(8);
        $uss=User::where('email',$email)->update([
        'password'=>Hash::make($hashed_random_password),
        ]);

        $to      = $request->email;
         $subject = "Password Reset";

        $message = "
        <html>
        <head>
        <title>HTML email</title>
        </head>
        <body>
        <h2>Your New Password!</h2>
        <h1 style=color:#f50000>$hashed_random_password</h1>
        </body>
        </html>
        ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: rashid.butt@appcrates.com' . "\r\n";
        $headers .= 'Cc: lal.bhinder@appcrates.com' . "\r\n";

        mail($to, $subject, $message, $headers);
        return response()->json(['status'=>"200",
       'description'=> "forget password",
       'message'=>"success",'data'=>'email send successfully']);
        }
        else{
            return response()->json(['status'=>"400",
       'description'=> "forget password",
       'message'=>"error",'data'=>'no such user exist']);
        }
}

public function logins(Request $request) {

        $email = $request->input('email');
        $password = $request->input('password');
        $messages = array(
            'email.required' => 'Please enter email',
             'password.required' => 'Please enter password',
        );
        $rules = array(
            'email' => 'required|email',
            'password' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('/')
                ->withErrors($validator)
                ->withInput();
        }

        $data=array ( 'email' => $email,'password' => $password ,'roles' => 'admin');
        if (Auth::attempt($data)) {

            return redirect('/manage_user');

        } else {

            Session::flash ( 'message', "Invalid Credentials , Please try again." );
            return redirect()->back();
        }

    }

public function update_profile_pic(Request $request)
    {
        if($request->hasfile('avatar')){

    $file=$request->file('avatar');
    $file_name=$file->getClientOriginalName();
    $f_imge = time().$file_name;
    $destinationPaths1 = app()->basePath('public/avatar');
    $file->move( $destinationPaths1,$f_imge);
     $user=User::where('id',$request->id)->update([
          'avatar'=>url('/').'/public/avatar/'.$f_imge,]);
    $users=User::where('id',$request->id)->first();
    return response()->json(['status'=>"200",
    'description'=> "update profile pic",
    'message'=>"success",'data'=>$users]);
        }


    }

public function update(Request $request)
    {
    if($request->appartment==0){
    $appartment=0;
    $vila=$request->vila;
   }
   if($request->vila==0){
    $vila=0;
    $appartment=$request->appartment;
   }
    $users=User::where('id',$request->user_id)->first();
    if(is_null($users)){
        return response()->json(['status'=>"200",
       'description'=> "error",
       'message'=>"no user exist",'data'=>'']);
    }
    if($request->hasfile('avatar')){

    $file=$request->file('avatar');
    $file_name=$file->getClientOriginalName();
    $f_imge = time().$file_name;
    $destinationPaths1 = app()->basePath('public/avatar');
    $file->move( $destinationPaths1,$f_imge);
    // echo url('/').'/public/images/'.$f_imge;
    // die;

        User::where('id',$request->user_id)->update([
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'avatar'=>url('/').'/public/avatar/'.$f_imge,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'region'=>$request->region,
            'phone_number'=>$request->phone_number,
            'address'=>$request->address,
            'state'=>$request->state,
            'appartment'=>$appartment,
            'device_token'=>$request->device_token,
            'city'=>$request->city,
            // 'delete_status'=>1,
            'vila'=>$vila,
            'building_no'=>$request->building_no,
            'flat_no'=>$request->flat_no,
            'house_no'=>$request->house_no,
            // 'status'=>1,
            // 'roles'=>'user',
        ]);
        $file=User::where('id',$request->user_id)->first();
       return response()->json(['status'=>"200",
       'description'=> "update profile",
       'message'=>"success",'data'=>$file]);
    }
    else{
     $user=User::where('id',$request->user_id)->first();
    User::where('id',$request->user_id)->update([
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'avatar'=>'',
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'region'=>$request->region,
            'phone_number'=>$request->phone_number,
            'address'=>$request->address,
            'state'=>$request->state,
            'appartment'=>$appartment,
            'device_token'=>$request->device_token,
            'city'=>$request->city,
            // 'delete_status'=>1,
            'vila'=>$vila,
            'building_no'=>$request->building_no,
            'flat_no'=>$request->flat_no,
            'house_no'=>$request->house_no,
            // 'status'=>1,
            // 'roles'=>'user',
        ]);
        $file=User::where('id',$request->user_id)->first();
       return response()->json(['status'=>"200",
       'description'=> "update profile",
       'message'=>"success",'data'=>$file]);
    }

    }


	public function get_profile(Request $request)
    {
        $user_id = $request->user_id;
        $user    = User::where('id',$user_id)->first();
        if(is_null($user)){

            return response()->json(['status_code'=>100,'status'=>'failure','data'=>'No User Exist']);
        }
        else{

            return response()->json(['status_code'=>200,'status'=>'success','data'=>$user]);
        }
    }

    public function get_logout()
    {
        Auth::logout();
        return redirect()->intended('/');
    }

    public function manage_user()
    {
    	$user=User::where('roles','user')->where('delete_status',1)->get();
    	return view('users',['users' => $user]);

    }

    public function delete_user($id)
    {
      User::where('id',$id)->delete();
       return  redirect()->intended('/manage_user')->with('delete','Deleted Successfully!');
    }

     public function change_password(Request $request){

     $user=User::where('id',$request->user_id)->first();
     if(is_null($user)){
         return response()->json(['status'=>"100",
       'description'=> "Change Password",
       'message'=>"success",'data'=>'No User Exist.']);
     }
    if(Hash::check($request->old_password,$user->password)){
     $users=User::where('id',$request->user_id)->update([
         'password'=>Hash::make($request->new_password),
         ]);
    return response()->json(['status'=>"200",
       'description'=> "Change Password",
       'message'=>"success",'data'=>'password change successfully.']);
    }
      else{
         return response()->json(['status'=>"100",
       'description'=> "Change Password",
       'message'=>$request->old_password.' is a wrong password!.','data'=>'']);
      }

     }


    public function get_users($id)
    {
$rec=DB::table('users')->where('users.id',$id)->first();
$address=DB::table('addresses')->where('user_id',$id)->get();
    if($rec->roles=='user'){
    	$html="";
    	if($rec->avatar!=''){
    	$html.='<div class="media-left">

            <div style="height:160px;" class="media-body">
            	<img src="'.$rec->avatar.'" style="width:150px;height:150px;" class="img-circle" >
            	<div class="col-sm-6 col-xs-12">

					<br /><span><b>Name:</b> '.$rec->first_name.' '.$rec->last_name.'</span>
					<br /><span><b>Email:</b> '.$rec->email.'</span>
                    <br /><span><b>Phone:</b> '.$rec->phone_number.'</span><br />
					';
    	}
    	else{
    	$html.='<div class="media-left">

            <div style="height:160px;" class="media-body">
            	<img src="<?php echo "'.url('/public/avatar/avatar.jpg').'"; ?>" style="width:150px;height:150px;" class="img-circle" >
            	<div class="col-sm-6 col-xs-12">

					<br /><span><b>Name:</b> '.$rec->first_name.' '.$rec->last_name.'</span>
					<br /><span><b>Email:</b> '.$rec->email.'</span>
                    <br /><span><b>Phone:</b> '.$rec->phone_number.'</span><br />
					';
    	}
            foreach($address as $key=> $value){
                $key=$key+1;
                if($value->appartment==1){
                $html.='<br /><span><b>'.$key.' Default Address:</b>'.$value->region.' '.$value->state.' '.$value->city.'
                    <br /><b>Building No:</b>'.$value->building_no.' </span><br />
                    <b>Flat No:</b>'.$value->flat_no.' </span><br />';
                    }
                    if($value->vila==1){
                $html.='<br /><span><b>'.$key.' Default Address:</b>'.$value->region.' '.$value->state.' '.$value->city.'
                    <br /><b>House No:</b>'.$value->house_no.' </span><br />';
                    }
            }
            $html.='</div>


                </div>
            </div>';
    	return response()->json($html);
 }

    }

    public function block_user($id)
    {
    	$data=array("status"=>'0');
        $record = Web_common::update_data($id,$data,"users");
       return  redirect()->intended('/manage_user');
    }

    public function un_block_user($id)
    {
    	$data=array("status"=>'1');
        $record = Web_common::update_data($id,$data,"users");
       return  redirect()->intended('/manage_user');
    }

   
    public function email_send(Request $request){
        $email_send=User::where('email',$request->email)->first();
        if(is_null($email_send)){
            return response()->json('null');
        }
        else{
            $hashed_random_password = str_random(8);
        $email_submit=User::where('id',$email_send->id)->update([
        'password'=>Hash::make($hashed_random_password),
        ]);

        $to      = $request->email;
         $subject = "Password Reset";

        $message = "
        <html>
        <head>
        <title>HTML email</title>
        </head>
        <body>
        <h2>Your New Password!</h2>
        <h1 style=color:#f50000>$hashed_random_password</h1>
        </body>
        </html>
        ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: rashid.butt@appcrates.com' . "\r\n";
        $headers .= 'Cc: lal.bhinder@appcrates.com' . "\r\n";

        mail($to, $subject, $message, $headers);
        return response()->json('send');
        }
    }
   
    public function send_mail($text,$email)
    {
        $data = array('text'=>$text, "name" => "hahahaha");
           $to=$email;
        Mail::to($to)->send(new ReplyMail($data));
        echo "Your Msg have been send to user via email";
    }


/****************** Bilal ******************************************/


    public function pust_notification()
    {
        // echo "string";
        return view('pust_notif');

    }


    public function send_push()
    {
        // echo "string";
        // die;
        $data=Input::all();

        // print_r($data);
        // die;

        $title = $data['title'];
        $body = $data['body'];

        $user=Web_common::get_user_token();

        // echo "<pre>";
        // print_r($user);
        // die;


        for ($i=0; $i < count($user) ; $i++)
        {

            if(empty($user[$i]->device_token))
            {

            }
            else
            {
                $tokens[] = $user[$i]->device_token;
                echo $this->send_push_noti($title,$body,$tokens);
            }

        }

        return  redirect()->intended('/pust_notification');

    }


    public function send_push_noti($title , $body ,$tokens )
    {

        // echo $title;
        // print_r($tokens);
        // die;

        $ch = curl_init();
        curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );



        //Custom data to be sent with the push
        $data = array
        (
            'message'      => 'here is a message. message',
            'title'        => $title,
            'body'         => $body,
            'smallIcon'    => 'small_icon',
            'some data'    => 'Some Data',
            'Another Data' => 'Another Data'
        );

        //This array contains, the token and the notification. The 'to' attribute stores the token.
        $arrayToSend = array(
                             'registration_ids' => $tokens,
                             'notification' => $data,
                             'priority'=>'high'
                              );



        //Generating JSON encoded string form the above array.
        $json = json_encode($arrayToSend);
        //Setup headers:
        $headers = array();
        $headers[] = 'Content-Type: application/json';

        $headers[] = 'Authorization: key= AIzaSyCTN7By31ZXru_2TOlLJZhahpDXAhy5vN0';


        //Setup curl, add headers and post parameters.

        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);

        //Send the request
        $response = curl_exec($ch);

        //Close request
        curl_close($ch);
        return $response;

        // echo $response;

    }

/****************** Zaid ******************************************/

     public function delete_event($id){

        $data=array("status"=>'2');
        $record = Web_common::delete_event($id,$data,"events");
        return  redirect()->back()->with('alert', 'Events deleted!');
    }



    public function changepassword()
     {
         return view('changePassword');
     }



      public function sendPasswordVar()
     {

        $data=Input::all();
        $oldpassword = $data['oldPassowrd'];
        $newpassword = $data['newPassowrd'];
        $confermpassword = $data['confermPassowrd'];


         $user = Auth::User();
        if($newpassword == $confermpassword){
            $current_password = $user->password;
              if (Hash::check($oldpassword, $current_password)){
                print_r("yes match value");
                echo "<br>";
                 $newpassword = Hash::make($newpassword);
                  print_r($newpassword);
                  echo "<br>";
                 $user_id = $user->id;
                 $data=array("password"=> $newpassword);
                 $newpassword = Web_common::newpassword($user_id,$data,"users");
                 print_r("yes change");
                echo "<br>";
                return  redirect('/');
              }
              else
              {

                return  redirect()->back()->with('message', 'Old Password is Incorect..!');
              }


        }else
        {

          return  redirect()->back()->with('message', 'Your Password In Not Match..!');
        }


     }

    public function password(Request $request){
       return view('password');
      }

    public function mit(Request $request){
        $array=$request->password1.$request->password2.$request->password3.$request->password4.$request->password5.$request->password6;
        // echo $array;
        $data1 = [
    'clientOtp' => $request->password1.$request->password2.$request->password3.$request->password4.$request->password5.$request->password6,
    ];
// ];
// $url="https://newdev.clickdietitian.com/webservice/free_consult_client_otp_login_mobile.php";
// $client = new Client([
//     'headers' => ['clickAuthorizeWebKeyMeetingRoom' => '5xpY2tkaWV0aXRpYW46sz60oiuU2NmhnZJlJCMj0mq',
//                    'Accept' => 'application/json',
//                    'content-type' => 'application/json',
// ],
// ]);

// // $options = [
// //     'form_params' => [
// //         'clientOtp' => $request->password1.$request->password2.$request->password3.$request->password4.$request->password5.$request->password6
// //        ]
// //    ]);
//    $response=$client->request('POST','https://newdev.clickdietitian.com/webservice/free_consult_client_otp_login_mobile.php',[
//     'json' => [
//             'clientOtp' =>$array,
//     ],
//    ]); 
//    $data=$response->getBody();
//    $data1=json_decode($data);
//    dd($data1);die;

//     $request = $client->post($url, $options);
//     dd($request);die;
//     $response = $request->send();

  
//     dd($response);
//       die;
$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://newdev.clickdietitian.com/webservice/free_consult_client_otp_login_mobile.php",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30000,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS =>$data1,
    // CURLOPT_HTTPHEADER => array(
    //     // Set here requred headers
    //     "accept: */*",
    //     "accept-language: en-US,en;q=0.8",
    //     "content-type: application/json",
    // ),
));
$headers = [
    'clickAuthorizeWebKeyMeetingRoom:5xpY2tkaWV0aXRpYW46sz60oiuU2NmhnZJlJCMj0mq'
];
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($curl);
 $response=json_decode($response);
// print_r($re->result);exit();

// foreach($response as $res){
//  $content = file_get_contents($res);
//  }
 $email=$response;
 // print_r($response->details->id);die;
 // $tidy = tidy_parse_string($response);
 curl_close($curl);
  return redirect('/password?'.$response->details->id.$response->details->email.$response->message);
    // $tidy->cleanRepair();
    // $content = (string)$tidy;

    // // load into DOM
    // $dom = new DOMDocument();
    // $dom->loadHTML($content);

    // // make xpath-able
    // $xpath = new DOMXPath($dom);

    // // search for the first td of each tr, where its content is $id
   
    // $elements = $xpath->query($query);
if ($elements->length != 1) {
        // not exactly 1 result as expected? return number of hits
        return $elements->length;
    }

return response()->json(['success'=>$response]);
$err = curl_error($curl);



if ($err) {
    echo "cURL Error #:" . $err;
} else {
   
}


    }

  public function manage_category(){
    $categories=Category::get();
    return view('category',compact('categories'));
  }

  public function new_category(){
    return view('new_category');
  }

  public function add_category(Request $request){
    $duplicate=Category::where('title_in_english',$request->title_in_english)->first();
    if(!is_null($duplicate)){
      return redirect('/new_category')->with('duplicate','Category is Already Exist');
    }
    if($request->hasfile('image')){
            $file=$request->file('image');
            $file_name=time().$file->getClientOriginalName();
            $destination=app()->basePath('public/images');
            $file->move($destination,$file_name);
    }
    Category::create([
            'title_in_english'=>$request->title_in_english,
            'title_in_arabic'=>$request->title_in_arabic,
            'image'=>url('/').'/public/images/'.$file_name,
            'status'=>1,
    ]);
    return redirect('/new_category')->with('success','Category Added');
  }

  public function edit_category($id){
    $category=Category::where('id',$id)->first();
    return view('edit_category',compact('category'));
  }

  public function update_category(Request $request){
    if($request->title_in_english!=$request->title_in_englishs){
    $duplicate=Category::where('title_in_english',$request->title_in_english)->first();
    if(!is_null($duplicate)){
      return redirect('/new_category')->with('duplicate','Category is Already Exist');
    }
  }
    if($request->hasfile('image')){
            $file=$request->file('image');
            $file_name=time().$file->getClientOriginalName();
            $destination=app()->basePath('public/images');
            $file->move($destination,$file_name);
            Category::where('id',$request->id)->update([
            'title_in_english'=>$request->title_in_english,
            'title_in_arabic'=>$request->title_in_arabic,
            'image'=>url('/').'/public/images/'.$file_name,
            'status'=>1,
    ]);
    }
            Category::where('id',$request->id)->update([
            'title_in_english'=>$request->title_in_english,
            'title_in_arabic'=>$request->title_in_arabic,
            'status'=>1,
    ]);
    
    return redirect('/manage_category')->with('update','Updated Successfully!');
  }

    public function block_category($id)
    {
      $data=array("status"=>'0');
        $record = Web_common::update_data($id,$data,"categories");
       return  redirect()->intended('/manage_category');
    }

    public function un_block_category($id)
    {
      $data=array("status"=>'1');
        $record = Web_common::update_data($id,$data,"categories");
       return  redirect()->intended('/manage_category');
    }

    public function delete_category($id)
    {
      Category::where('id',$id)->delete();
       return  redirect()->intended('/manage_category')->with('delete','Deleted Successfully!');
    }


    public function get_category($id)
    {
      $rec=DB::table('categories')->
      where('id',$id)->first();
     
    
      $html="";
      $html.='<div class="media-left">

            <div style="height:160px;" class="media-body">
              <img src="'.$rec->image.'" style="width:150px" class="img-circle" >
              <div class="col-sm-6 col-xs-12">

          <br /><span><b>Title:</b> '.$rec->title_in_english.' '.$rec->title_in_arabic.'</span><br />
          



          </div>


              </div>
            </div>';

      return response()->json($html);
 

    }


 public function manage_product(){
    $products=Product::
    join('categories','products.category_id','=','categories.id')
    ->where('categories.status',1)
    ->select('products.id','products.title_in_english','products.title_in_arabic','products.description_in_english','products.description_in_arabic','products.status','products.price','products.discounted_price','products.image','categories.title_in_english as category_name')
    ->get();
    return view('product',compact('products'));
  }

  public function new_product(){
    $categories=Category::where('status',1)->get();
    return view('new_product',compact('categories'));
  }

  public function add_product(Request $request){
    $duplicate=Product::where('title_in_english',$request->title_in_english)->first();
    if(!is_null($duplicate)){
      return redirect('/new_product')->with('duplicate','Product is Already Exist');
    }
    if($request->hasfile('image')){
            $file=$request->file('image');
            $file_name=time().$file->getClientOriginalName();
            $destination=app()->basePath('public/images');
            $file->move($destination,$file_name);
    }
    Product::create([
            'title_in_english'=>$request->title_in_english,
            'title_in_arabic'=>$request->title_in_arabic,
            'description_in_english'=>$request->description_in_english,
            'description_in_arabic'=>$request->description_in_arabic,
            'category_id'=>$request->category_id,
            'image'=>url('/').'/public/images/'.$file_name,
            'price'=>$request->price,
            'discounted_price'=>$request->discounted_price,
            'status'=>1,
    ]);
    return redirect('/new_product')->with('success','Product Added');
  }

  public function edit_product($id){
    $product=Product::where('id',$id)->first();
    return view('edit_product',compact('product'));
  }

  public function update_product(Request $request){
    if($request->title_in_english!=$request->title_in_englishs){
    $duplicate=Product::where('title_in_english',$request->title_in_english)->first();
    if(!is_null($duplicate)){
      return redirect('/new_product')->with('duplicate','Product is Already Exist');
    }
  }
    if($request->hasfile('image')){
            $file=$request->file('image');
            $file_name=time().$file->getClientOriginalName();
            $destination=app()->basePath('public/images');
            $file->move($destination,$file_name);
            Product::where('id',$request->id)->update([
            'title_in_english'=>$request->title_in_english,
            'title_in_arabic'=>$request->title_in_arabic,
            'description_in_english'=>$request->description_in_english,
            'description_in_arabic'=>$request->description_in_arabic,
            'category_id'=>$request->category_id,
            'image'=>url('/').'/public/images/'.$file_name,
            'price'=>$request->price,
            'discounted_price'=>$request->discounted_price,
            'status'=>1,
    ]);
    }
            Product::where('id',$request->id)->update([
            'title_in_english'=>$request->title_in_english,
            'title_in_arabic'=>$request->title_in_arabic,
            'description_in_english'=>$request->description_in_english,
            'description_in_arabic'=>$request->description_in_arabic,
            'category_id'=>$request->category_id,
            'price'=>$request->price,
            'discounted_price'=>$request->discounted_price,
            'status'=>1,
    ]);
    
    return redirect('/manage_product')->with('update','Updated Successfully!');
  }

    public function block_product($id)
    {
      $data=array("status"=>'0');
        $record = Web_common::update_data($id,$data,"products");
       return  redirect()->intended('/manage_product');
    }

    public function un_block_product($id)
    {
      $data=array("status"=>'1');
        $record = Web_common::update_data($id,$data,"products");
       return  redirect()->intended('/manage_product');
    }

    public function delete_product($id)
    {
      Product::where('id',$id)->delete();
       return  redirect()->intended('/manage_product')->with('delete','Deleted Successfully!');
    }


    public function get_product($id)
    {
      $rec=DB::table('products')->
      where('id',$id)->first();
     
    
      $html="";
      $html.='<div class="media-left">

            <div style="height:160px;" class="media-body">
              <img src="'.$rec->image.'" style="width:150px" class="img-circle" >
              <div class="col-sm-6 col-xs-12">

          <br /><span><b>Title:</b> '.$rec->title_in_english.' '.$rec->title_in_arabic.'</span><br />
          <br /><span><b>Price:</b> '.$rec->price.'</span><br />
          



          </div>


              </div>
            </div>';

      return response()->json($html);
 

    }

    public function manage_order(){
        $orders=Order::
        join('users','orders.user_id','=','users.id')->
        select('orders.id','orders.total_price','orders.payment_method','orders.payment_status','order_status','orders.date','orders.discount','users.first_name','users.last_name')->
        get();
        return view('order',compact('orders'));
    }

    public function block_order($id)
    {
        $data=array("status"=>'0');
        $record = Web_common::update_data($id,$data,"orders");
        return  redirect()->intended('/manage_order');
    }

    public function un_block_order($id)
    {
        $data=array("status"=>'1');
        $record = Web_common::update_data($id,$data,"orders");
        return  redirect()->intended('/manage_order');
    }

    public function paid_payment_status($id)
    {
        $data=array("payment_status"=>'0');
        $record = Web_common::update_data($id,$data,"orders");
        return  redirect()->intended('/manage_order');
    }

    public function pending_payment_status($id)
    {
        $data=array("payment_status"=>'1');
        $record = Web_common::update_data($id,$data,"orders");
        return  redirect()->intended('/manage_order');
    }
    public function order_status(Request $request,$id)
    {   if($request->complete){
        $data=array("order_status"=>'2');
    }
        if($request->cancel){
        $data=array("order_status"=>'0');
    }
        if($request->active){
        $data=array("order_status"=>'1');
    }
        $record = Web_common::update_data($id,$data,"orders");
        return  redirect()->intended('/manage_order');
    }
    
    public function orderdetail($id)
    {  $orders= Order::
        join('orderdetails','orderdetails.order_id','=','orders.id')->
        join('users','orders.user_id','=','users.id')->
        join('products','orderdetails.product_id','=','products.id')->
        select('orders.id','orders.date','orders.discount','orders.total_price','orders.order_status','orders.payment_method','orders.payment_status',
        'products.title_in_english','products.title_in_arabic','products.image'
        ,'products.price','orderdetails.quantity','orderdetails.price','users.first_name','users.last_name')->
        where('orders.id',$id)->
        get();
        
        return view('orderdetail',compact('orders'));
    }

}
