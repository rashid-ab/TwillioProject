<?php $__env->startSection('content'); ?>
<style type="text/css">
.overlay{

    opacity:0.8;

    background-color:#ccc;

    position:fixed;

    width:100%;

    height:100%;

    top:0px;

    left:0px;

    z-index:1000;

    display: none;



}

.overlay img {

    position: relative;

    z-index: 99999;

    left: 48%;

    right: -40%;

    top: 40%;

    width: 5%;

}

</style>
<span>Order ID: <?php echo e($order['order_id']); ?></span>
<span>Customer Name: <?php echo e($order['name']); ?></span>
<span>Date: <?php echo e($order['date']); ?></span>
<span>Time: <?php echo e($order['time']); ?></span>
<span>Address: <?php echo e($order['address']); ?></span>
<span>Total Price: <?php echo e($order['total_price']); ?></span>
<span>Payment Method: <?php echo e($order['payment_method']); ?></span>
<span>Payment Status: <?php echo e($order['payment_status']); ?></span>
<?php $__currentLoopData = $order['order_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<span>Product Name: <?php echo e($ord->product_title_in_english); ?> <?php echo e($ord->product_title_in_arabic); ?></span>
<span><img src="<?php echo e($ord->image); ?>" style="width:200px;height:200px" /> </span>
<span>Quantity: <?php echo e($ord->quantity); ?></span>
<span>Price Per Product: <?php echo e($ord->price); ?></span>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v72appcrates/public_html/zahib1/resources/views/orderdetail.blade.php ENDPATH**/ ?>