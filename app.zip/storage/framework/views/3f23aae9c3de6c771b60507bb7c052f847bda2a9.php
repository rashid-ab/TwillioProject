



<?php $__env->startSection('content'); ?>



<style type="text/css">

    

    .overlay{

    opacity:0.8;

    background-color:#ccc;

    position:fixed;

    width:100%;

    height:100%;

    top:0px;

    left:0px;

    z-index:1000;

    display: none;



}

.overlay img {

    position: relative;

    z-index: 99999;

    left: 48%;

    right: -40%;

    top: 40%;

    width: 5%;

}




</style>

    <section id="main-content" >

        <section class="wrapper">

            <!-- page start-->

            <div class="row">
<div class="col-sm-4" >
</div>
                <div class="col-sm-4" >

                    <section class="panel">

                        <header class="panel-heading">


                          <?php if(Session::has('success')): ?>
           <div class="alert alert-success">
             <?php echo e(Session::get('success')); ?>

           </div>
        <?php endif; ?>
        
                          <?php if(Session::has('duplicate')): ?>
           <div class="alert alert-danger">
             <?php echo e(Session::get('duplicate')); ?>

           </div>
        <?php endif; ?>
            
          
                           
                            Add Category

                            <div class="btn-holder" style="float: right;">

                           <!--  <a href="<?php echo e(url('newcustomer')); ?>"><button type="button" class="btn btn-danger">Add New</button></a> -->

                            </div>

                        </header>

                        <div class="panel-body">

                        <!--         <form role="form"> -->
                        <form role="form" method="post" 
                              class="add_employee" enctype="multipart/form-data">

        						 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                 <div class="form-group">
                                      <label>Title in English</label>
                                      <input type="text" class="form-control" 
                                      name="title_in_english" required >


                                 </div>

                                 <div class="form-group">
                                      <label>Title in Arabic</label>
                                      <input type="text" class="form-control" 
                                      name="title_in_arabic" required >
                                 </div>

                                 <div class="form-group">
                                      <label>Image</label>
                                      <input type="file" class="form-control avatar" 
                                      name="image" required >
                                 </div>
								
								 <button type="submit" class="btn btn-success ">Save</button>
                                  
                            </form>

                        </div>

                    </section>

                </div>

            </div>



            <!-- page end-->

        </section>

    </section>

    <!--dynamic table initialization -->    
<script
  src="https://code.jquery.com/jquery-3.4.0.js"
  integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo="
  crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<!---->

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v72appcrates/public_html/zahib1/resources/views/new_category.blade.php ENDPATH**/ ?>